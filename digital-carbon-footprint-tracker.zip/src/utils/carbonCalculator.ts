import { ActivityLog, AISuggestion, Achievement } from '../types';

export const EMISSION_FACTORS = {
  videoStreaming: 0.10,   // kg CO2e per hour
  internetUsage: 0.03,    // kg CO2e per GB
  deviceCharging: 0.02,   // kg CO2e per hour
  cloudStorage: 0.002,    // kg CO2e per GB
  emailsSent: 0.004,      // kg CO2e per email
  onlineMeetings: 0.12,   // kg CO2e per hour
  gaming: 0.09,           // kg CO2e per hour
  aiUsage: 0.003,         // kg CO2e per AI query/interaction
};

export function calculateActivityCO2(activity: Omit<ActivityLog, 'id' | 'userId' | 'date' | 'totalCO2Kg'>): number {
  const total =
    (activity.videoStreamingHours || 0) * EMISSION_FACTORS.videoStreaming +
    (activity.internetUsageGB || 0) * EMISSION_FACTORS.internetUsage +
    (activity.deviceChargingHours || 0) * EMISSION_FACTORS.deviceCharging +
    (activity.cloudStorageGB || 0) * EMISSION_FACTORS.cloudStorage +
    (activity.emailsSent || 0) * EMISSION_FACTORS.emailsSent +
    (activity.onlineMeetingsHours || 0) * EMISSION_FACTORS.onlineMeetings +
    (activity.gamingHours || 0) * EMISSION_FACTORS.gaming +
    (activity.aiUsage || 0) * EMISSION_FACTORS.aiUsage;

  return Math.round(total * 1000) / 1000;
}

export function calculateCarbonScore(dailyCO2Kg: number): number {
  if (dailyCO2Kg === 0) return 98;
  if (dailyCO2Kg <= 0.4) return 95;
  if (dailyCO2Kg <= 0.8) return 88;
  if (dailyCO2Kg <= 1.5) return 78;
  if (dailyCO2Kg <= 2.5) return 65;
  if (dailyCO2Kg <= 4.0) return 50;
  return Math.max(20, Math.round(100 - dailyCO2Kg * 12));
}

export function getGreenBadge(carbonScore: number, totalCO2SavedKg: number): {
  badgeName: string;
  badgeLevel: string;
  color: string;
  iconName: string;
  description: string;
} {
  if (carbonScore >= 90 || totalCO2SavedKg >= 10) {
    return {
      badgeName: 'Planet Guardian',
      badgeLevel: 'Level 4 (Elite)',
      color: '#10B981',
      iconName: 'ShieldCheck',
      description: 'Exceptional digital sustainability practices! You are setting an inspiring benchmark.'
    };
  } else if (carbonScore >= 80 || totalCO2SavedKg >= 5) {
    return {
      badgeName: 'Eco Warrior',
      badgeLevel: 'Level 3 (Advanced)',
      color: '#16A34A',
      iconName: 'Leaf',
      description: 'Significantly lower emissions than the global average. Great work reducing digital waste!'
    };
  } else if (carbonScore >= 65 || totalCO2SavedKg >= 2) {
    return {
      badgeName: 'Green Enthusiast',
      badgeLevel: 'Level 2 (Intermediate)',
      color: '#0EA5E9',
      iconName: 'Zap',
      description: 'Actively monitoring digital consumption and implementing daily energy-saving tips.'
    };
  } else {
    return {
      badgeName: 'Digital Novice',
      badgeLevel: 'Level 1 (Beginner)',
      color: '#F59E0B',
      iconName: 'Sprout',
      description: 'Starting your digital decarbonization journey. Explore AI Suggestions to improve your score!'
    };
  }
}

export function generateAISuggestions(activities: ActivityLog[]): AISuggestion[] {
  const latest = activities[0] || {
    videoStreamingHours: 2,
    internetUsageGB: 5,
    deviceChargingHours: 4,
    cloudStorageGB: 50,
    emailsSent: 20,
    onlineMeetingsHours: 1.5,
    gamingHours: 1,
    aiUsage: 10
  };

  const suggestions: AISuggestion[] = [
    {
      id: 'sug-1',
      title: 'Reduce Video Streaming Quality',
      description: 'Switching video stream from 4K/1080p to 720p or HD uses up to 50% less data and bandwidth.',
      category: 'Streaming',
      estimatedSavingKg: Math.min(0.4, Math.round((latest.videoStreamingHours || 2) * 0.08 * 100) / 100),
      impactLevel: 'High',
      actionableTip: 'Lower streaming resolution in app settings (YouTube, Netflix, Twitch).'
    },
    {
      id: 'sug-2',
      title: 'Delete Unused Cloud Files & Duplicates',
      description: 'Data centers consume electricity 24/7 storing stale files, duplicate photos, and massive video backups.',
      category: 'Cloud',
      estimatedSavingKg: Math.min(0.25, Math.round((latest.cloudStorageGB || 30) * 0.003 * 100) / 100),
      impactLevel: 'Medium',
      actionableTip: 'Perform a monthly digital declutter on Drive/iCloud and delete unneeded archives.'
    },
    {
      id: 'sug-3',
      title: 'Enable Battery Saver & Smart Power Profile',
      description: 'Power saving mode limits background CPU processes and lowers screen brightness, extending battery health.',
      category: 'Power',
      estimatedSavingKg: 0.12,
      impactLevel: 'Medium',
      actionableTip: 'Activate dark mode and automatic screen sleep after 2 minutes of inactivity.'
    },
    {
      id: 'sug-4',
      title: 'Prefer Wi-Fi Over Mobile Data (4G/5G)',
      description: 'Wi-Fi networks are up to 4x more energy efficient per gigabyte transferred than cellular base stations.',
      category: 'Network',
      estimatedSavingKg: Math.min(0.3, Math.round((latest.internetUsageGB || 5) * 0.02 * 100) / 100),
      impactLevel: 'High',
      actionableTip: 'Connect to home or office Wi-Fi when downloading large updates or streaming.'
    },
    {
      id: 'sug-5',
      title: 'Limit Unnecessary Reply-All & Thank You Emails',
      description: 'Sending short single-word emails to large recipient lists creates unnecessary carbon across mail servers.',
      category: 'Email',
      estimatedSavingKg: Math.min(0.15, Math.round((latest.emailsSent || 15) * 0.004 * 100) / 100),
      impactLevel: 'Low',
      actionableTip: 'Unsubscribe from promotional newsletters and group channels you no longer read.'
    },
    {
      id: 'sug-6',
      title: 'Unplug Chargers After Reaching 100%',
      description: 'Vampire draw consumes energy even when devices are fully charged or disconnected.',
      category: 'Power',
      estimatedSavingKg: 0.08,
      impactLevel: 'Low',
      actionableTip: 'Use smart plugs or disconnect power strips when chargers are not active.'
    },
    {
      id: 'sug-7',
      title: 'Switch to Renewable Energy Cloud Providers',
      description: 'Support hosting services and cloud vendors powered by 100% wind, solar, or hydro power sources.',
      category: 'Energy',
      estimatedSavingKg: 0.35,
      impactLevel: 'High',
      actionableTip: 'Choose green cloud hosts and eco-conscious web search engines like Ecosia.'
    }
  ];

  return suggestions;
}

export function getAchievements(activities: ActivityLog[], totalCO2SavedKg: number, streakDays: number): Achievement[] {
  const totalEntries = activities.length;
  const maxScore = activities.length > 0
    ? Math.max(...activities.map(a => calculateCarbonScore(a.totalCO2Kg)))
    : 0;

  return [
    {
      id: 'ach-1',
      title: 'First Step to Decarbonization',
      description: 'Log your first digital carbon activity record.',
      iconName: 'Footprints',
      unlocked: totalEntries >= 1,
      progress: Math.min(100, Math.round((totalEntries / 1) * 100)),
      targetLabel: `${Math.min(1, totalEntries)} / 1 log`
    },
    {
      id: 'ach-2',
      title: 'Consistency Champion',
      description: 'Maintain a 5-day active tracking streak.',
      iconName: 'Flame',
      unlocked: streakDays >= 5,
      progress: Math.min(100, Math.round((streakDays / 5) * 100)),
      targetLabel: `${streakDays} / 5 days`
    },
    {
      id: 'ach-3',
      title: 'CO₂ Saver Master',
      description: 'Save a cumulative 2.5 kg of CO₂ through eco actions.',
      iconName: 'Recycle',
      unlocked: totalCO2SavedKg >= 2.5,
      progress: Math.min(100, Math.round((totalCO2SavedKg / 2.5) * 100)),
      targetLabel: `${totalCO2SavedKg.toFixed(2)} / 2.5 kg`
    },
    {
      id: 'ach-4',
      title: 'Digital Eco Master',
      description: 'Achieve a Carbon Score of 85 or higher on any day.',
      iconName: 'Award',
      unlocked: maxScore >= 85,
      progress: Math.min(100, Math.round((maxScore / 85) * 100)),
      targetLabel: `${Math.min(100, maxScore)} / 85 score`
    },
    {
      id: 'ach-5',
      title: 'Green Titan',
      description: 'Log 15 or more digital activities in total.',
      iconName: 'Globe',
      unlocked: totalEntries >= 15,
      progress: Math.min(100, Math.round((totalEntries / 15) * 100)),
      targetLabel: `${totalEntries} / 15 logs`
    }
  ];
}
