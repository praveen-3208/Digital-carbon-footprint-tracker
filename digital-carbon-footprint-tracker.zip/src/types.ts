export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  createdAt: string;
  carbonScore: number;
  totalCO2Saved: number;
  streakDays: number;
  lastActiveDate: string;
}

export interface ActivityLog {
  id?: string;
  userId: string;
  date: string; // YYYY-MM-DD
  videoStreamingHours: number;
  internetUsageGB: number;
  deviceChargingHours: number;
  cloudStorageGB: number;
  emailsSent: number;
  onlineMeetingsHours: number;
  gamingHours: number;
  aiUsage: number;
  totalCO2Kg: number;
  createdAt?: any;
}

export interface AISuggestion {
  id: string;
  title: string;
  description: string;
  category: 'Streaming' | 'Cloud' | 'Power' | 'Network' | 'Email' | 'Energy' | 'General';
  estimatedSavingKg: number;
  impactLevel: 'High' | 'Medium' | 'Low';
  actionableTip: string;
  isImplemented?: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  iconName: string;
  unlocked: boolean;
  progress: number; // 0 to 100
  targetLabel: string;
}
