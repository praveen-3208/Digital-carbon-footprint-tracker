import React, { useState } from 'react';
import { Leaf, Heart, Shield, Info, Mail, Github } from 'lucide-react';
import { FooterModals } from './FooterModals';

export const Footer: React.FC = () => {
  const [modalType, setModalType] = useState<'about' | 'privacy' | 'contact' | 'github' | null>(null);

  return (
    <footer className="mt-auto bg-[#061109] border-t border-[#153e24] text-slate-400 py-8 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Brand info */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white tracking-wide">
              Digital Carbon Footprint Tracker
            </div>
            <div className="text-xs text-slate-400">
              Measuring & reducing online carbon emissions worldwide.
            </div>
          </div>
        </div>

        {/* Footer Navigation Links */}
        <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-medium">
          <button
            onClick={() => setModalType('about')}
            className="hover:text-green-400 transition-colors flex items-center gap-1.5"
          >
            <Info className="w-3.5 h-3.5" />
            About
          </button>
          <button
            onClick={() => setModalType('privacy')}
            className="hover:text-green-400 transition-colors flex items-center gap-1.5"
          >
            <Shield className="w-3.5 h-3.5" />
            Privacy Policy
          </button>
          <button
            onClick={() => setModalType('contact')}
            className="hover:text-green-400 transition-colors flex items-center gap-1.5"
          >
            <Mail className="w-3.5 h-3.5" />
            Contact
          </button>
          <button
            onClick={() => setModalType('github')}
            className="hover:text-green-400 transition-colors flex items-center gap-1.5"
          >
            <Github className="w-3.5 h-3.5" />
            GitHub
          </button>
        </div>

        {/* Copyright & Tagline */}
        <div className="text-xs text-slate-400 flex items-center gap-1">
          <span>Crafted with</span>
          <Heart className="w-3.5 h-3.5 text-green-500 fill-green-500 inline" />
          <span>for a greener digital web</span>
        </div>
      </div>

      <FooterModals activeModal={modalType} onClose={() => setModalType(null)} />
    </footer>
  );
};
