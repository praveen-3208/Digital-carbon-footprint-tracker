import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  PlusCircle,
  TrendingUp,
  Sparkles,
  User,
  LogOut,
  Menu,
  X,
  Leaf
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { userProfile, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Activity', path: '/activity', icon: PlusCircle },
    { name: 'AI Suggestions', path: '/suggestions', icon: Sparkles },
    { name: 'Progress', path: '/progress', icon: TrendingUp },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <nav className="sticky top-0 z-40 w-full bg-[#061109]/90 backdrop-blur-xl border-b border-[#153e24]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand Name */}
          <NavLink to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 p-0.5 shadow-lg shadow-green-950/50 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#0b1d11] rounded-[10px] flex items-center justify-center">
                <Leaf className="w-5 h-5 text-green-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <div>
              <span className="text-lg font-bold text-white tracking-tight block">
                CARBON<span className="text-green-400">TRACK</span>
              </span>
              <span className="text-[10px] uppercase font-semibold tracking-wider text-green-300/60 block -mt-1">
                Digital Decarbonization
              </span>
            </div>
          </NavLink>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1.5 bg-[#0b1d11]/90 border border-[#153e24] p-1.5 rounded-2xl shadow-inner">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                      isActive
                        ? 'bg-green-600 text-white shadow-md shadow-green-900/50'
                        : 'text-slate-300 hover:text-white hover:bg-[#153e24]/60'
                    }`
                  }
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </NavLink>
              );
            })}
          </div>

          {/* User Profile & Logout Quick Actions */}
          <div className="hidden md:flex items-center gap-3">
            {userProfile && (
              <NavLink
                to="/profile"
                className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full bg-[#0b1d11] border border-[#153e24] hover:border-green-500/50 transition-colors"
              >
                <img
                  src={
                    userProfile.photoURL ||
                    `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userProfile.name)}`
                  }
                  alt={userProfile.name}
                  className="w-8 h-8 rounded-full bg-green-950/80 object-cover"
                />
                <div className="text-left">
                  <div className="text-xs font-semibold text-white leading-tight">
                    {userProfile.name.split(' ')[0]}
                  </div>
                  <div className="text-[10px] text-green-400 font-mono">
                    Score: {userProfile.carbonScore}
                  </div>
                </div>
              </NavLink>
            )}

            <button
              onClick={handleLogout}
              title="Logout"
              className="p-2.5 text-slate-400 hover:text-rose-400 bg-[#0b1d11] hover:bg-rose-950/40 border border-[#153e24] hover:border-rose-900/50 rounded-xl transition-all"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2.5 text-slate-300 hover:text-white bg-[#0b1d11] border border-[#153e24] rounded-xl"
            >
              {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileOpen && (
        <div className="md:hidden bg-[#061109]/95 border-b border-[#153e24] px-4 pt-2 pb-6 space-y-2 animate-fadeIn">
          {userProfile && (
            <div className="flex items-center gap-3 p-3 bg-[#0b1d11] border border-[#153e24] rounded-xl mb-3">
              <img
                src={
                  userProfile.photoURL ||
                  `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userProfile.name)}`
                }
                alt={userProfile.name}
                className="w-10 h-10 rounded-full bg-green-950/80"
              />
              <div>
                <div className="text-sm font-bold text-white">{userProfile.name}</div>
                <div className="text-xs text-green-400 font-mono">
                  Carbon Score: {userProfile.carbonScore} | Saved: {userProfile.totalCO2Saved.toFixed(1)} kg
                </div>
              </div>
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-green-600 text-white'
                      : 'text-slate-300 hover:bg-[#0b1d11] hover:text-white'
                  }`
                }
              >
                <Icon className="w-5 h-5 text-green-400" />
                <span>{item.name}</span>
              </NavLink>
            );
          })}

          <button
            onClick={() => {
              setMobileOpen(false);
              handleLogout();
            }}
            className="w-full flex items-center justify-center gap-2 mt-4 px-4 py-3 text-sm font-semibold text-rose-400 bg-rose-950/30 border border-rose-900/40 hover:bg-rose-900/50 rounded-xl transition-all"
          >
            <LogOut className="w-4 h-4" />
            Logout Account
          </button>
        </div>
      )}
    </nav>
  );
};
