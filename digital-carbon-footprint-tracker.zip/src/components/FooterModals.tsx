import React, { useState } from 'react';
import { X, Info, Shield, Mail, Github, CheckCircle2, Leaf, Send } from 'lucide-react';

interface FooterModalsProps {
  activeModal: 'about' | 'privacy' | 'contact' | 'github' | null;
  onClose: () => void;
}

export const FooterModals: React.FC<FooterModalsProps> = ({ activeModal, onClose }) => {
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactMsg, setContactMsg] = useState({ name: '', email: '', message: '' });

  if (!activeModal) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
    setTimeout(() => {
      setContactSubmitted(false);
      setContactMsg({ name: '', email: '', message: '' });
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#0b1d11] border border-[#153e24] rounded-2xl p-6 sm:p-8 text-slate-200 shadow-2xl overflow-y-auto max-h-[85vh]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl bg-[#153e24]/60 hover:bg-[#153e24] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {activeModal === 'about' && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400">
                <Info className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">About Digital Carbon Footprint Tracker</h2>
            </div>
            <div className="space-y-4 text-sm leading-relaxed text-slate-300">
              <p>
                The <strong>Digital Carbon Footprint Tracker</strong> empowers individuals and organizations to measure, manage, and minimize the hidden environmental impact of their online activities.
              </p>
              <p>
                From HD video streaming and cloud storage data centers to AI queries and mobile base station power, every gigabyte processed generates greenhouse gas emissions.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
                <div className="p-4 bg-[#061109] border border-[#153e24] rounded-xl">
                  <div className="text-green-400 font-bold mb-1">Data Processing</div>
                  <div className="text-xs text-slate-400">0.03 kg CO₂ / GB Internet Transfer</div>
                </div>
                <div className="p-4 bg-[#061109] border border-[#153e24] rounded-xl">
                  <div className="text-sky-400 font-bold mb-1">Video Streaming</div>
                  <div className="text-xs text-slate-400">0.10 kg CO₂ / Hour HD Video</div>
                </div>
              </div>
              <p>
                Our mission is to foster digital sustainability through actionable AI suggestions, daily streak tracking, and interactive carbon score analytics.
              </p>
            </div>
          </div>
        )}

        {activeModal === 'privacy' && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-sky-500/10 border border-sky-500/30 rounded-xl text-sky-400">
                <Shield className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">Privacy Policy</h2>
            </div>
            <div className="space-y-4 text-sm leading-relaxed text-slate-300">
              <p>
                Your privacy and data security are our highest priorities. We strictly limit data collection to what is necessary for calculating your digital emissions.
              </p>
              <div className="space-y-2">
                <h4 className="font-semibold text-white">1. Information We Store</h4>
                <p className="text-xs text-slate-400">
                  Firebase Authentication stores your email and display name securely. Activity parameters (streaming hours, data usage, charging duration) are stored in your encrypted Firebase Firestore user partition.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-white">2. No Third-Party Tracking</h4>
                <p className="text-xs text-slate-400">
                  We do not sell, rent, or trade user data to advertisers or third parties. All metrics remain private to your authenticated account.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-white">3. Data Control</h4>
                <p className="text-xs text-slate-400">
                  You can log out, view your activity records, or request complete account purge at any time through your Profile settings.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeModal === 'contact' && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
                <Mail className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">Contact Eco Support</h2>
            </div>

            {contactSubmitted ? (
              <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h3 className="text-lg font-bold text-white">Thank You!</h3>
                <p className="text-xs text-emerald-300">Your message has been received. Our green team will respond shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={contactMsg.name}
                    onChange={(e) => setContactMsg({ ...contactMsg, name: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500"
                    placeholder="Jane Doe"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Your Email
                  </label>
                  <input
                    type="email"
                    required
                    value={contactMsg.email}
                    onChange={(e) => setContactMsg({ ...contactMsg, email: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500"
                    placeholder="jane@example.com"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Message
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={contactMsg.message}
                    onChange={(e) => setContactMsg({ ...contactMsg, message: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500"
                    placeholder="How can we help reduce your carbon footprint?"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            )}
          </div>
        )}

        {activeModal === 'github' && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-white">
                <Github className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white">GitHub Repository & Architecture</h2>
            </div>
            <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
              <p>
                This project is open-source and built with modern web sustainability standards:
              </p>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 space-y-1">
                <div>Frontend: React (Vite) + Tailwind CSS + Lucide Icons</div>
                <div>Charts: Chart.js + react-chartjs-2</div>
                <div>Backend: Firebase Auth + Cloud Firestore</div>
                <div>Calculations: Standard GHG Digital Footprint Factors</div>
              </div>
              <div className="flex items-center gap-4 pt-2">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noreferrer"
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-sm font-semibold flex items-center gap-2 border border-slate-700"
                >
                  <Github className="w-4 h-4" />
                  View GitHub Repo
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
