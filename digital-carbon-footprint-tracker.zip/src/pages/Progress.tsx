import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { ActivityLog } from '../types';
import { calculateCarbonScore, getGreenBadge, getAchievements } from '../utils/carbonCalculator';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

import {
  TrendingUp,
  Award,
  Flame,
  CheckCircle2,
  ShieldCheck,
  Footprints,
  Recycle,
  Globe,
  Leaf,
  Calendar,
  Sparkles
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const Progress: React.FC = () => {
  const { currentUser, userProfile } = useAuth();

  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [weeklyData, setWeeklyData] = useState<{ labels: string[]; values: number[] }>({
    labels: [],
    values: []
  });
  const [monthlyData, setMonthlyData] = useState<{ labels: string[]; values: number[] }>({
    labels: [],
    values: []
  });

  useEffect(() => {
    async function loadProgressData() {
      if (!currentUser) return;
      try {
        const q = query(
          collection(db, 'activities'),
          where('userId', '==', currentUser.uid),
          orderBy('date', 'desc'),
          limit(60)
        );
        const snapshot = await getDocs(q);
        const logs: ActivityLog[] = [];
        snapshot.forEach((doc) => logs.push(doc.data() as ActivityLog));

        setActivities(logs);

        // 1. Calculate Weekly Chart (Last 7 Days)
        const daysMap: { [dateStr: string]: number } = {};
        const wLabels: string[] = [];
        const wValues: number[] = [];

        for (let i = 6; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dateKey = d.toISOString().split('T')[0];
          const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
          daysMap[dateKey] = 0;
          wLabels.push(dayName);
        }

        logs.forEach((act) => {
          if (daysMap[act.date] !== undefined) {
            daysMap[act.date] += act.totalCO2Kg;
          }
        });

        Object.keys(daysMap).forEach((dateKey) => {
          wValues.push(Math.round(daysMap[dateKey] * 1000) / 1000);
        });

        setWeeklyData({ labels: wLabels, values: wValues });

        // 2. Calculate Monthly Chart (Last 4 Weeks / Months)
        const monthMap: { [monthStr: string]: number } = {};
        const mLabels: string[] = [];
        const mValues: number[] = [];

        for (let i = 3; i >= 0; i--) {
          const d = new Date();
          d.setMonth(d.getMonth() - i);
          const monthKey = d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
          monthMap[monthKey] = 0;
          mLabels.push(monthKey);
        }

        logs.forEach((act) => {
          const actDate = new Date(act.date);
          const monthKey = actDate.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
          if (monthMap[monthKey] !== undefined) {
            monthMap[monthKey] += act.totalCO2Kg;
          }
        });

        Object.keys(monthMap).forEach((mKey) => {
          mValues.push(Math.round(monthMap[mKey] * 1000) / 1000);
        });

        setMonthlyData({ labels: mLabels, values: mValues });
      } catch (err) {
        console.error('Error loading progress analytics:', err);
      }
    }

    loadProgressData();
  }, [currentUser]);

  const carbonScore = userProfile?.carbonScore || 85;
  const totalSaved = userProfile?.totalCO2Saved || 0;
  const streakDays = userProfile?.streakDays || 1;

  const greenBadge = getGreenBadge(carbonScore, totalSaved);
  const achievements = getAchievements(activities, totalSaved, streakDays);

  // Weekly Chart Setup
  const weeklyChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0f172a',
        borderColor: '#10b981',
        borderWidth: 1,
        titleColor: '#f8fafc',
        bodyColor: '#34d399',
        padding: 12
      }
    },
    scales: {
      x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } },
      y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' }, beginAtZero: true }
    }
  };

  const weeklyChartConfig = {
    labels: weeklyData.labels,
    datasets: [
      {
        label: 'Weekly CO₂ (kg)',
        data: weeklyData.values,
        backgroundColor: '#10b981',
        borderRadius: 8,
        hoverBackgroundColor: '#34d399'
      }
    ]
  };

  // Monthly Chart Setup
  const monthlyChartConfig = {
    labels: monthlyData.labels,
    datasets: [
      {
        fill: true,
        label: 'Monthly CO₂ (kg)',
        data: monthlyData.values,
        borderColor: '#0ea5e9',
        backgroundColor: 'rgba(14, 165, 233, 0.15)',
        tension: 0.3,
        pointBackgroundColor: '#38bdf8',
        pointRadius: 6
      }
    ]
  };

  const getAchievementIcon = (name: string) => {
    switch (name) {
      case 'Footprints': return Footprints;
      case 'Flame': return Flame;
      case 'Recycle': return Recycle;
      case 'Award': return Award;
      default: return Globe;
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1d11] via-[#0f2918] to-[#061109] border border-[#153e24] p-6 sm:p-8 shadow-2xl">
        <div className="flex items-center gap-2 text-green-400 font-semibold text-xs uppercase tracking-wider mb-2">
          <TrendingUp className="w-4 h-4" />
          <span>Progress & Analytics</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Decarbonization Progress Dashboard
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
          Track your long-term environmental metrics, review weekly and monthly emission charts, monitor your active streak, and unlock sustainability badges!
        </p>
      </div>

      {/* Top 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Carbon Score */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Carbon Score
            </span>
            <div className="p-2.5 bg-green-500/10 text-green-400 rounded-xl">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-green-400 font-mono">
            {carbonScore} <span className="text-xs text-slate-400 font-normal">/ 100</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Overall eco sustainability score</p>
        </div>

        {/* Total CO2 Saved */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total CO₂ Saved
            </span>
            <div className="p-2.5 bg-sky-500/10 text-sky-400 rounded-xl">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            {totalSaved.toFixed(2)}{' '}
            <span className="text-sm font-sans font-normal text-slate-400">kg</span>
          </div>
          <p className="text-[11px] text-green-400 mt-2">Cumulative prevented emissions</p>
        </div>

        {/* Streak Days */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Streak Days
            </span>
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
              <Flame className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-amber-400 font-mono">
            {streakDays} <span className="text-sm font-sans font-normal text-slate-400">Days</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Consecutive active logging days</p>
        </div>

        {/* Green Badge Status */}
        <div className="glass-card glass-card-hover rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Green Badge
            </span>
            <div className="p-2.5 bg-green-500/10 text-green-400 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-white" style={{ color: greenBadge.color }}>
            {greenBadge.badgeName}
          </div>
          <p className="text-[11px] text-slate-400 mt-2">{greenBadge.badgeLevel}</p>
        </div>
      </div>

      {/* Charts Section: Weekly & Monthly Side by Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Weekly Chart */}
        <div className="glass-card rounded-3xl p-6 shadow-2xl">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-green-400" />
              Weekly Carbon Chart
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">7-day breakdown of digital emissions</p>
          </div>
          <div className="h-60 w-full">
            <Bar data={weeklyChartConfig} options={weeklyChartOptions} />
          </div>
        </div>

        {/* Monthly Chart */}
        <div className="glass-card rounded-3xl p-6 shadow-2xl">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-sky-400" />
              Monthly Carbon Chart
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Aggregated monthly emissions history</p>
          </div>
          <div className="h-60 w-full">
            <Line data={monthlyChartConfig} options={weeklyChartOptions} />
          </div>
        </div>
      </div>

      {/* Achievements Section */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Award className="w-6 h-6 text-green-400" />
            Unlockable Achievements
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Complete milestones through continuous tracking and decarbonization efforts
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((ach) => {
            const Icon = getAchievementIcon(ach.iconName);

            return (
              <div
                key={ach.id}
                className={`p-5 rounded-2xl border transition-all ${
                  ach.unlocked
                    ? 'bg-green-950/40 border-green-500/50 text-white shadow-lg shadow-green-950/40'
                    : 'bg-[#061109]/60 border-[#153e24] text-slate-400'
                }`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className={`p-3 rounded-xl ${
                      ach.unlocked
                        ? 'bg-green-500/20 text-green-400 border border-green-500/40'
                        : 'bg-[#153e24]/60 text-slate-500 border border-[#153e24]'
                    }`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{ach.title}</h4>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-green-400">
                      {ach.unlocked ? 'Unlocked' : 'In Progress'}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {ach.description}
                </p>

                {/* Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Progress</span>
                    <span className="text-green-400 font-bold">{ach.targetLabel}</span>
                  </div>
                  <div className="w-full h-2 bg-[#061109] rounded-full overflow-hidden border border-[#153e24]">
                    <div
                      className="h-full bg-green-500 rounded-full transition-all duration-500"
                      style={{ width: `${ach.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
