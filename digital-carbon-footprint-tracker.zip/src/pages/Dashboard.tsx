import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { ActivityLog } from '../types';
import { calculateCarbonScore, getGreenBadge } from '../utils/carbonCalculator';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  Filler
} from 'chart.js';
import { Line } from 'react-chartjs-2';

import {
  PlusCircle,
  Sparkles,
  User,
  LogOut,
  Leaf,
  Calendar,
  TrendingUp,
  Award,
  Zap,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Trash2,
  Activity as ActivityIcon
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const Dashboard: React.FC = () => {
  const { userProfile, currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Stats calculation
  const [todayEmission, setTodayEmission] = useState(0);
  const [weeklyEmission, setWeeklyEmission] = useState(0);
  const [weeklyChartData, setWeeklyChartData] = useState<{ labels: string[]; values: number[] }>({
    labels: [],
    values: []
  });

  useEffect(() => {
    async function loadUserActivities() {
      if (!currentUser) return;
      try {
        const q = query(
          collection(db, 'activities'),
          where('userId', '==', currentUser.uid),
          orderBy('date', 'desc'),
          limit(30)
        );
        const querySnapshot = await getDocs(q);
        const logs: ActivityLog[] = [];
        querySnapshot.forEach((doc) => {
          logs.push({ id: doc.id, ...doc.data() } as ActivityLog);
        });

        setActivities(logs);

        // Process Today & Weekly Emissions
        const todayStr = new Date().toISOString().split('T')[0];

        let todayKg = 0;
        let weekKg = 0;

        // Calculate last 7 days chart array
        const daysMap: { [dateStr: string]: number } = {};
        const labels: string[] = [];
        const values: number[] = [];

        for (let i = 6; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dateKey = d.toISOString().split('T')[0];
          const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
          daysMap[dateKey] = 0;
          labels.push(dayName);
        }

        logs.forEach((act) => {
          if (act.date === todayStr) {
            todayKg += act.totalCO2Kg;
          }

          // Check if within last 7 days
          if (daysMap[act.date] !== undefined) {
            daysMap[act.date] += act.totalCO2Kg;
            weekKg += act.totalCO2Kg;
          }
        });

        Object.keys(daysMap).forEach((dateKey) => {
          values.push(Math.round(daysMap[dateKey] * 1000) / 1000);
        });

        setTodayEmission(Math.round(todayKg * 1000) / 1000);
        setWeeklyEmission(Math.round(weekKg * 1000) / 1000);
        setWeeklyChartData({ labels, values });
      } catch (err) {
        console.error('Error loading dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadUserActivities();
  }, [currentUser]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const carbonScore = userProfile?.carbonScore || calculateCarbonScore(todayEmission);
  const greenBadge = getGreenBadge(carbonScore, userProfile?.totalCO2Saved || 0);

  // Chart configuration
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0f172a',
        borderColor: '#10b981',
        borderWidth: 1,
        titleColor: '#f8fafc',
        bodyColor: '#34d399',
        padding: 12,
        boxPadding: 6,
        callbacks: {
          label: (context: any) => ` Emission: ${context.raw} kg CO₂e`
        }
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.05)' },
        ticks: { color: '#94a3b8', font: { size: 12, weight: 'bold' as const } }
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.05)' },
        ticks: { color: '#94a3b8', font: { size: 12 } },
        beginAtZero: true
      }
    }
  };

  const lineChartData = {
    labels: weeklyChartData.labels,
    datasets: [
      {
        fill: true,
        label: 'Carbon Emission (kg)',
        data: weeklyChartData.values,
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.15)',
        tension: 0.4,
        pointBackgroundColor: '#34d399',
        pointBorderColor: '#064e3b',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7
      }
    ]
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1d11] via-[#0f2918] to-[#061109] border border-[#153e24] p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-green-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/30 text-green-400 text-xs font-semibold mb-3">
              <Leaf className="w-3.5 h-3.5" />
              <span>Digital Carbon Footprint Tracker</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Welcome, <span className="text-green-400">{userProfile?.name || 'Eco Leader'}</span>!
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
              Monitor your daily video streaming, cloud storage, AI usage, and device charging to build sustainable digital habits.
            </p>
          </div>

          {/* Badge Widget */}
          <div className="flex items-center gap-3 bg-[#061109]/80 border border-[#153e24] p-4 rounded-2xl shadow-lg backdrop-blur-md shrink-0">
            <div className="p-3 bg-green-500/20 text-green-400 rounded-xl">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                Badge Status
              </div>
              <div className="text-base font-bold text-white" style={{ color: greenBadge.color }}>
                {greenBadge.badgeName}
              </div>
              <div className="text-xs text-slate-400">{greenBadge.badgeLevel}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <Link
          to="/activity"
          className="flex items-center gap-3 p-4 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-bold text-sm shadow-lg shadow-green-950/60 transition-all hover:scale-[1.02]"
        >
          <PlusCircle className="w-5 h-5 shrink-0" />
          <span>Add Activity</span>
        </Link>
        <Link
          to="/suggestions"
          className="flex items-center gap-3 p-4 bg-[#0b1d11] hover:bg-[#0f2918] text-sky-400 border border-sky-500/30 rounded-2xl font-bold text-sm shadow-lg transition-all hover:scale-[1.02]"
        >
          <Sparkles className="w-5 h-5 shrink-0" />
          <span>AI Suggestions</span>
        </Link>
        <Link
          to="/profile"
          className="flex items-center gap-3 p-4 bg-[#0b1d11] hover:bg-[#0f2918] text-slate-200 border border-[#153e24] rounded-2xl font-bold text-sm shadow-lg transition-all hover:scale-[1.02]"
        >
          <User className="w-5 h-5 shrink-0 text-green-400" />
          <span>Profile</span>
        </Link>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 p-4 bg-[#0b1d11] hover:bg-rose-950/50 text-rose-400 border border-rose-900/40 rounded-2xl font-bold text-sm shadow-lg transition-all hover:scale-[1.02]"
        >
          <LogOut className="w-5 h-5 shrink-0" />
          <span>Logout</span>
        </button>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Today's Emission */}
        <div className="glass-card glass-card-hover rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Today's Carbon Emission
            </span>
            <div className="p-2.5 bg-green-500/10 border border-green-500/20 rounded-xl text-green-400">
              <Zap className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            {todayEmission}{' '}
            <span className="text-sm font-sans font-normal text-slate-400">kg CO₂e</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {todayEmission > 1.5 ? '⚠️ Above daily target limit' : '✓ Within healthy green limit'}
          </p>
        </div>

        {/* Weekly Emission */}
        <div className="glass-card glass-card-hover rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Weekly Carbon Emission
            </span>
            <div className="p-2.5 bg-sky-500/10 border border-sky-500/20 rounded-xl text-sky-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            {weeklyEmission}{' '}
            <span className="text-sm font-sans font-normal text-slate-400">kg CO₂e</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Sum of logged activities over 7 days</p>
        </div>

        {/* Carbon Score */}
        <div className="glass-card glass-card-hover rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Carbon Score
            </span>
            <div className="p-2.5 bg-green-500/10 border border-green-500/20 rounded-xl text-green-400">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-green-400 font-mono">
            {carbonScore} <span className="text-sm text-slate-400 font-normal">/ 100</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Higher score indicates lower carbon impact</p>
        </div>

        {/* Total CO2 Saved */}
        <div className="glass-card glass-card-hover rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total CO₂ Saved
            </span>
            <div className="p-2.5 bg-green-500/10 border border-green-500/20 rounded-xl text-green-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            {(userProfile?.totalCO2Saved || 0).toFixed(2)}{' '}
            <span className="text-sm font-sans font-normal text-slate-400">kg CO₂</span>
          </div>
          <p className="text-[11px] text-green-400 mt-2">Saved through eco actions & tips</p>
        </div>
      </div>

      {/* Weekly Carbon Chart Section */}
      <div className="glass-card rounded-3xl p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ActivityIcon className="w-5 h-5 text-green-400" />
              Weekly Carbon Emission Trend
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Daily CO₂ equivalent footprint over the past 7 days
            </p>
          </div>
          <Link
            to="/progress"
            className="text-xs font-semibold text-green-400 hover:text-green-300 flex items-center gap-1 bg-green-950/40 border border-green-800/50 px-3 py-1.5 rounded-xl self-start sm:self-auto"
          >
            <span>View Full Analytics</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="h-64 sm:h-72 w-full">
          <Line data={lineChartData} options={chartOptions} />
        </div>
      </div>

      {/* Recent Activities Section */}
      <div className="glass-card rounded-3xl p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-green-400" />
            Recent Logged Activities
          </h2>
          <Link
            to="/activity"
            className="text-xs font-semibold text-green-400 hover:text-green-300 flex items-center gap-1"
          >
            <span>+ Add Entry</span>
          </Link>
        </div>

        {activities.length === 0 ? (
          <div className="p-8 text-center bg-[#061109]/50 border border-dashed border-[#153e24] rounded-2xl">
            <Leaf className="w-10 h-10 text-green-500/40 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-white">No Activities Recorded Yet</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              Start tracking your digital carbon footprint by logging your streaming, charging, cloud, or gaming hours!
            </p>
            <Link
              to="/activity"
              className="inline-flex items-center gap-2 mt-4 px-5 py-2.5 bg-green-600 hover:bg-green-500 text-white font-semibold text-xs rounded-xl transition-all shadow-lg"
            >
              <PlusCircle className="w-4 h-4" />
              Log Your First Activity
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-[#153e24] text-slate-400 uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Streaming</th>
                  <th className="py-3 px-4">Internet Data</th>
                  <th className="py-3 px-4">Cloud Storage</th>
                  <th className="py-3 px-4">AI Usage</th>
                  <th className="py-3 px-4 text-right">CO₂ Emission</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#153e24]/60 text-slate-300">
                {activities.slice(0, 5).map((act, idx) => (
                  <tr key={act.id || idx} className="hover:bg-[#153e24]/30 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-medium text-white flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-green-400 shrink-0" />
                      {act.date}
                    </td>
                    <td className="py-3.5 px-4">{act.videoStreamingHours || 0} hrs</td>
                    <td className="py-3.5 px-4">{act.internetUsageGB || 0} GB</td>
                    <td className="py-3.5 px-4">{act.cloudStorageGB || 0} GB</td>
                    <td className="py-3.5 px-4">{act.aiUsage || 0} queries</td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-green-400">
                      {act.totalCO2Kg} kg
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
