import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Leaf, Mail, Lock, LogIn, AlertCircle, Loader2, ArrowRight, Sparkles } from 'lucide-react';
import { ForgotPasswordModal } from '../components/ForgotPasswordModal';

export const Login: React.FC = () => {
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [forgotModalOpen, setForgotModalOpen] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setLoading(true);

    try {
      await login(email, password);
      navigate('/');
    } catch (err: any) {
      console.error('Login error:', err);
      let message = 'Failed to sign in. Please check your credentials.';
      if (err.code === 'auth/invalid-email') message = 'Invalid email format.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        message = 'Account not found or password incorrect. Try "Quick Demo Login" or register below.';
      }
      setErrorMsg(message);
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setErrorMsg('');
    setDemoLoading(true);
    const demoEmail = 'demo@carbontrack.eco';
    const demoPass = 'password123';

    try {
      await login(demoEmail, demoPass);
      navigate('/');
    } catch (err: any) {
      // If demo account doesn't exist yet, auto-register it!
      try {
        await register('Demo Eco Leader', demoEmail, demoPass);
        navigate('/');
      } catch (regErr: any) {
        console.error('Demo auto-register error:', regErr);
        setErrorMsg('Failed to log in with demo account. Please try registering a new account.');
      }
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#061109] flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden bg-geometric-grid">
      
      {/* Background ambient glow shapes */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-sky-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md relative z-10">
        
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 p-0.5 shadow-xl shadow-green-950/80 mb-4">
            <div className="w-full h-full bg-[#0b1d11] rounded-[14px] flex items-center justify-center">
              <Leaf className="w-8 h-8 text-green-400" />
            </div>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Digital Carbon <span className="text-green-400">Tracker</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Sign in to track and reduce your digital CO₂ emissions
          </p>
        </div>

        {/* Login Form Card */}
        <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-2xl shadow-green-950/40">
          <div className="flex items-center gap-2 mb-6 text-green-400 font-semibold text-sm">
            <LogIn className="w-4 h-4" />
            <span>Welcome Back</span>
          </div>

          {errorMsg && (
            <div className="p-3.5 mb-6 rounded-2xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs sm:text-sm flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-[#061109]/90 border border-[#153e24] focus:border-green-500 rounded-xl py-3 pl-11 pr-4 text-white placeholder-slate-500 text-sm focus:outline-none transition-all"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setForgotModalOpen(true)}
                  className="text-xs text-green-400 hover:text-green-300 font-medium transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#061109]/90 border border-[#153e24] focus:border-green-500 rounded-xl py-3 pl-11 pr-4 text-white placeholder-slate-500 text-sm focus:outline-none transition-all"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || demoLoading}
              className="w-full py-3.5 px-4 bg-green-600 hover:bg-green-500 active:scale-[0.99] disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-green-950/80 flex items-center justify-center gap-2 text-sm"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Authenticating...
                </>
              ) : (
                <>
                  <span>Login to Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Access Button */}
          <div className="mt-4">
            <button
              type="button"
              onClick={handleDemoLogin}
              disabled={loading || demoLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-emerald-900/60 via-green-900/60 to-teal-900/60 hover:from-emerald-800/80 hover:to-teal-800/80 text-green-300 hover:text-white font-semibold rounded-xl transition-all text-sm flex items-center justify-center gap-2 border border-green-500/40 shadow-md active:scale-[0.99]"
            >
              {demoLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-green-400" />
                  Logging into Demo...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-green-400" />
                  <span>⚡ One-Click Demo Login</span>
                </>
              )}
            </button>
          </div>

          {/* Divider */}
          <div className="my-6 border-t border-[#153e24] text-center relative">
            <span className="bg-[#0b1d11] px-3 text-xs text-slate-400 absolute -top-2.5 left-1/2 -translate-x-1/2">
              New to CarbonTrack?
            </span>
          </div>

          {/* Create Account Button */}
          <Link
            to="/register"
            className="w-full py-3 px-4 bg-[#153e24]/60 hover:bg-[#153e24] text-slate-200 hover:text-white font-semibold rounded-xl transition-all text-sm flex items-center justify-center gap-2 border border-[#153e24]"
          >
            Create New Account
          </Link>
        </div>

        {/* Footer info */}
        <p className="text-center text-xs text-slate-500 mt-6">
          Protected by Firebase Security & Encrypted Firestore Rules
        </p>
      </div>

      <ForgotPasswordModal
        isOpen={forgotModalOpen}
        onClose={() => setForgotModalOpen(false)}
        initialEmail={email}
      />
    </div>
  );
};
