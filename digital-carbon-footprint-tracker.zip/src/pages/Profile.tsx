import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import {
  User,
  Mail,
  Award,
  Activity,
  LogOut,
  CheckCircle2,
  Leaf,
  ShieldCheck,
  Calendar,
  Edit3,
  Camera,
  Check,
  Sparkles
} from 'lucide-react';
import { getGreenBadge } from '../utils/carbonCalculator';

export const Profile: React.FC = () => {
  const { userProfile, currentUser, logout, updateUserPhoto } = useAuth();
  const navigate = useNavigate();

  const [totalActivities, setTotalActivities] = useState(0);
  const [editingPhoto, setEditingPhoto] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState('');
  const [savingPhoto, setSavingPhoto] = useState(false);

  useEffect(() => {
    async function loadActivityCount() {
      if (!currentUser) return;
      try {
        const q = query(collection(db, 'activities'), where('userId', '==', currentUser.uid));
        const snapshot = await getDocs(q);
        setTotalActivities(snapshot.size);
      } catch (err) {
        console.error('Error fetching activity count:', err);
      }
    }

    loadActivityCount();
  }, [currentUser]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const presetAvatars = [
    `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userProfile?.name || 'eco1')}`,
    `https://api.dicebear.com/7.x/bottts/svg?seed=GreenLeaf7`,
    `https://api.dicebear.com/7.x/bottts/svg?seed=EarthProtector`,
    `https://api.dicebear.com/7.x/bottts/svg?seed=SolarPower`
  ];

  const handleSavePhoto = async (url: string) => {
    setSavingPhoto(true);
    try {
      await updateUserPhoto(url);
      setEditingPhoto(false);
    } catch (e) {
      console.error(e);
    } finally {
      setSavingPhoto(false);
    }
  };

  const carbonScore = userProfile?.carbonScore || 85;
  const totalSaved = userProfile?.totalCO2Saved || 0;
  const greenBadge = getGreenBadge(carbonScore, totalSaved);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      
      {/* Profile Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1d11] via-[#0f2918] to-[#061109] border border-[#153e24] p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-12 -bottom-12 w-80 h-80 bg-green-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-6 sm:gap-8 text-center md:text-left">
          
          {/* User Avatar */}
          <div className="relative group">
            <img
              src={
                userProfile?.photoURL ||
                `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userProfile?.name || 'Eco')}`
              }
              alt={userProfile?.name}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover bg-[#061109] border-2 border-green-500/50 p-1 shadow-2xl shadow-green-950/80"
            />
            <button
              onClick={() => setEditingPhoto(!editingPhoto)}
              className="absolute -bottom-2 -right-2 p-2 bg-green-600 hover:bg-green-500 text-white rounded-xl shadow-lg border border-green-400/50 transition-all"
              title="Change Avatar"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* User Details */}
          <div className="flex-1 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/30 text-green-400 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{greenBadge.badgeName}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {userProfile?.name || 'Eco User'}
            </h1>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-slate-300">
              <span className="flex items-center gap-1.5 font-mono">
                <Mail className="w-4 h-4 text-green-400 shrink-0" />
                {userProfile?.email || currentUser?.email}
              </span>
              <span className="flex items-center gap-1.5 font-mono">
                <Calendar className="w-4 h-4 text-sky-400 shrink-0" />
                Joined:{' '}
                {userProfile?.createdAt
                  ? new Date(userProfile.createdAt).toLocaleDateString()
                  : 'Active Member'}
              </span>
            </div>

            <p className="text-xs text-slate-400 pt-2 leading-relaxed max-w-xl">
              {greenBadge.description}
            </p>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="px-5 py-2.5 bg-rose-950/50 hover:bg-rose-900/60 border border-rose-900/50 text-rose-300 hover:text-white font-semibold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout Account</span>
          </button>
        </div>

        {/* Preset Avatar Picker Dropdown */}
        {editingPhoto && (
          <div className="mt-6 p-4 bg-[#061109] border border-[#153e24] rounded-2xl animate-fadeIn space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Choose an Eco Avatar Preset
            </h4>
            <div className="flex flex-wrap gap-4">
              {presetAvatars.map((url, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSavePhoto(url)}
                  disabled={savingPhoto}
                  className="w-14 h-14 rounded-2xl bg-[#0b1d11] border border-[#153e24] hover:border-green-500 overflow-hidden transition-all hover:scale-105 p-1"
                >
                  <img src={url} alt={`Avatar preset ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 3 Core Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        
        {/* Total Activities */}
        <div className="glass-card glass-card-hover rounded-2xl p-6 shadow-xl">
          <div className="p-3 bg-green-500/10 text-green-400 rounded-xl w-fit mb-3">
            <Activity className="w-6 h-6" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">{totalActivities}</div>
          <div className="text-xs text-slate-400 mt-1 font-semibold">Total Activities Logged</div>
        </div>

        {/* Carbon Score */}
        <div className="glass-card glass-card-hover rounded-2xl p-6 shadow-xl">
          <div className="p-3 bg-sky-500/10 text-sky-400 rounded-xl w-fit mb-3">
            <Award className="w-6 h-6" />
          </div>
          <div className="text-3xl font-extrabold text-sky-400 font-mono">{carbonScore}</div>
          <div className="text-xs text-slate-400 mt-1 font-semibold">Current Carbon Score</div>
        </div>

        {/* Total CO2 Saved */}
        <div className="glass-card glass-card-hover rounded-2xl p-6 shadow-xl">
          <div className="p-3 bg-green-500/10 text-green-400 rounded-xl w-fit mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div className="text-3xl font-extrabold text-green-400 font-mono">
            {totalSaved.toFixed(2)} kg
          </div>
          <div className="text-xs text-slate-400 mt-1 font-semibold">Total CO₂ Saved</div>
        </div>
      </div>

      {/* Account Settings / Eco Profile Details */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Leaf className="w-5 h-5 text-green-400" />
          Account & Security Information
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
          <div className="p-4 bg-[#061109]/80 border border-[#153e24] rounded-2xl">
            <span className="text-slate-400 font-semibold block mb-1">Authentication Method</span>
            <span className="text-white font-medium">Firebase Email Authentication</span>
          </div>

          <div className="p-4 bg-[#061109]/80 border border-[#153e24] rounded-2xl">
            <span className="text-slate-400 font-semibold block mb-1">Cloud Database Storage</span>
            <span className="text-white font-medium">Firebase Firestore (Encrypted)</span>
          </div>

          <div className="p-4 bg-[#061109]/80 border border-[#153e24] rounded-2xl">
            <span className="text-slate-400 font-semibold block mb-1">Badge Level</span>
            <span className="text-green-400 font-bold">{greenBadge.badgeLevel}</span>
          </div>

          <div className="p-4 bg-[#061109]/80 border border-[#153e24] rounded-2xl">
            <span className="text-slate-400 font-semibold block mb-1">Active Streak</span>
            <span className="text-amber-400 font-bold">{userProfile?.streakDays || 1} Days</span>
          </div>
        </div>
      </div>
    </div>
  );
};
