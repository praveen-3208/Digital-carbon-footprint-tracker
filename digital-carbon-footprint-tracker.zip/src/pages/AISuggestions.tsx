import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { ActivityLog, AISuggestion } from '../types';
import { generateAISuggestions } from '../utils/carbonCalculator';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Tv,
  Cloud,
  Zap,
  Globe,
  Mail,
  Sun,
  CheckCircle2,
  TrendingDown,
  Award,
  ArrowRight,
  ShieldCheck,
  Leaf
} from 'lucide-react';

export const AISuggestions: React.FC = () => {
  const { currentUser, userProfile, addCO2Saved } = useAuth();

  const [suggestions, setSuggestions] = useState<AISuggestion[]>([]);
  const [implementedIds, setImplementedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadSuggestionsData() {
      if (!currentUser) return;
      try {
        const q = query(
          collection(db, 'activities'),
          where('userId', '==', currentUser.uid),
          orderBy('date', 'desc'),
          limit(5)
        );
        const snapshot = await getDocs(q);
        const logs: ActivityLog[] = [];
        snapshot.forEach((doc) => logs.push(doc.data() as ActivityLog));

        const list = generateAISuggestions(logs);
        setSuggestions(list);
      } catch (err) {
        console.error('Error loading AI suggestions:', err);
      } finally {
        setLoading(false);
      }
    }

    loadSuggestionsData();
  }, [currentUser]);

  const handleImplement = async (sug: AISuggestion) => {
    if (implementedIds.includes(sug.id)) return;

    // Trigger confetti
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#34d399', '#0ea5e9']
      });
    } catch (e) {
      // ignore
    }

    setImplementedIds((prev) => [...prev, sug.id]);

    // Add CO2 saved to user profile in Firestore
    await addCO2Saved(sug.estimatedSavingKg);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Streaming': return Tv;
      case 'Cloud': return Cloud;
      case 'Power': return Zap;
      case 'Network': return Globe;
      case 'Email': return Mail;
      case 'Energy': return Sun;
      default: return Sparkles;
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1d11] via-[#0f2918] to-[#061109] border border-[#153e24] p-6 sm:p-8 shadow-2xl">
        <div className="flex items-center gap-2 text-sky-400 font-semibold text-xs uppercase tracking-wider mb-2">
          <Sparkles className="w-4 h-4" />
          <span>AI Recommendations Engine</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Personalized AI Decarbonization Tips
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
          Based on your logged digital usage, our AI engine generated actionable tips to reduce emissions. Implement recommendations below to earn CO₂ savings and boost your Carbon Score!
        </p>

        {/* Saved Stats Banner */}
        <div className="mt-6 flex flex-wrap items-center gap-4 pt-4 border-t border-[#153e24]">
          <div className="flex items-center gap-3 bg-[#061109]/90 border border-[#153e24] px-4 py-2.5 rounded-2xl">
            <Leaf className="w-5 h-5 text-green-400" />
            <div>
              <div className="text-[10px] uppercase font-semibold text-slate-400">Total Saved</div>
              <div className="text-sm font-bold text-white font-mono">
                {(userProfile?.totalCO2Saved || 0).toFixed(2)} kg CO₂
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#061109]/90 border border-sky-500/30 px-4 py-2.5 rounded-2xl">
            <Award className="w-5 h-5 text-sky-400" />
            <div>
              <div className="text-[10px] uppercase font-semibold text-slate-400">Carbon Score</div>
              <div className="text-sm font-bold text-white font-mono">
                {userProfile?.carbonScore || 85} / 100
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* List of Suggestions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {suggestions.map((sug) => {
          const CategoryIcon = getCategoryIcon(sug.category);
          const isDone = implementedIds.includes(sug.id);

          return (
            <div
              key={sug.id}
              className={`relative overflow-hidden rounded-3xl p-6 border transition-all duration-300 flex flex-col justify-between ${
                isDone
                  ? 'bg-green-950/40 border-green-500/60 shadow-xl'
                  : 'glass-card glass-card-hover shadow-xl'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 bg-green-500/10 border border-green-500/20 text-green-400 rounded-xl">
                      <CategoryIcon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#153e24]/80 text-slate-300 uppercase tracking-wider">
                      {sug.category}
                    </span>
                  </div>

                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      sug.impactLevel === 'High'
                        ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                        : sug.impactLevel === 'Medium'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {sug.impactLevel} Impact
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white mb-2">{sug.title}</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                  {sug.description}
                </p>

                <div className="p-3 bg-[#061109]/80 border border-[#153e24] rounded-xl mb-6 text-xs text-green-300 flex items-start gap-2">
                  <Leaf className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                  <span><strong>Action Tip:</strong> {sug.actionableTip}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-[#153e24] flex items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">
                    Estimated Saving
                  </span>
                  <span className="text-base font-extrabold text-green-400 font-mono">
                    ~{sug.estimatedSavingKg} kg CO₂
                  </span>
                </div>

                <button
                  onClick={() => handleImplement(sug)}
                  disabled={isDone}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
                    isDone
                      ? 'bg-green-900/60 text-green-300 border border-green-500/40 cursor-default'
                      : 'bg-green-600 hover:bg-green-500 text-white shadow-lg shadow-green-950/80 hover:scale-[1.02]'
                  }`}
                >
                  {isDone ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      Saved!
                    </>
                  ) : (
                    <>
                      <TrendingDown className="w-4 h-4" />
                      Implement & Save
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
