import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { collection, addDoc, serverTimestamp, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { calculateActivityCO2 } from '../utils/carbonCalculator';
import {
  PlusCircle,
  Tv,
  Globe,
  Zap,
  Cloud,
  Mail,
  Video,
  Gamepad2,
  Bot,
  CheckCircle2,
  Loader2,
  AlertCircle,
  Leaf,
  Calculator,
  ArrowRight
} from 'lucide-react';

export const Activity: React.FC = () => {
  const { currentUser, userProfile, refreshUserProfile } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    videoStreamingHours: 0,
    internetUsageGB: 0,
    deviceChargingHours: 0,
    cloudStorageGB: 0,
    emailsSent: 0,
    onlineMeetingsHours: 0,
    gamingHours: 0,
    aiUsage: 0
  });

  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<{ emission: number } | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Live total calculation while typing
  const liveCO2 = calculateActivityCO2(formData);

  const handleChange = (field: string, value: string) => {
    const num = Math.max(0, parseFloat(value) || 0);
    setFormData((prev) => ({ ...prev, [field]: num }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg(null);

    if (!currentUser) {
      setErrorMsg('You must be logged in to record an activity.');
      return;
    }

    const totalCO2Kg = calculateActivityCO2(formData);

    if (totalCO2Kg === 0) {
      setErrorMsg('Please enter values for at least one activity.');
      return;
    }

    setSubmitting(true);

    try {
      // 1. Save activity log to Firestore
      const activityData = {
        userId: currentUser.uid,
        date: formData.date || new Date().toISOString().split('T')[0],
        videoStreamingHours: formData.videoStreamingHours,
        internetUsageGB: formData.internetUsageGB,
        deviceChargingHours: formData.deviceChargingHours,
        cloudStorageGB: formData.cloudStorageGB,
        emailsSent: formData.emailsSent,
        onlineMeetingsHours: formData.onlineMeetingsHours,
        gamingHours: formData.gamingHours,
        aiUsage: formData.aiUsage,
        totalCO2Kg,
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'activities'), activityData);

      // 2. Update streak and user profile in Firestore
      if (userProfile) {
        const todayStr = new Date().toISOString().split('T')[0];
        let newStreak = userProfile.streakDays || 1;

        if (userProfile.lastActiveDate) {
          const lastDate = new Date(userProfile.lastActiveDate);
          const todayDate = new Date(todayStr);
          const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));
          if (diffDays === 1) {
            newStreak += 1;
          } else if (diffDays > 1) {
            newStreak = 1;
          }
        }

        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, {
          streakDays: newStreak,
          lastActiveDate: todayStr
        });
        await refreshUserProfile();
      }

      setSuccessMsg({ emission: totalCO2Kg });

      // Reset form fields
      setFormData({
        date: new Date().toISOString().split('T')[0],
        videoStreamingHours: 0,
        internetUsageGB: 0,
        deviceChargingHours: 0,
        cloudStorageGB: 0,
        emailsSent: 0,
        onlineMeetingsHours: 0,
        gamingHours: 0,
        aiUsage: 0
      });
    } catch (err: any) {
      console.error('Error recording activity:', err);
      setErrorMsg('Failed to store activity in Firestore. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const fields = [
    {
      id: 'videoStreamingHours',
      label: 'Video Streaming',
      unit: 'Hours',
      icon: Tv,
      color: 'text-rose-400',
      bgColor: 'bg-rose-500/10 border-rose-500/20',
      placeholder: 'e.g. 2.5',
      hint: 'HD video uses ~0.10 kg CO₂ / hr'
    },
    {
      id: 'internetUsageGB',
      label: 'Internet Usage',
      unit: 'GB Data',
      icon: Globe,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/10 border-sky-500/20',
      placeholder: 'e.g. 10',
      hint: 'Network processing uses ~0.03 kg CO₂ / GB'
    },
    {
      id: 'deviceChargingHours',
      label: 'Device Charging',
      unit: 'Hours',
      icon: Zap,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-500/20',
      placeholder: 'e.g. 4',
      hint: 'Laptop & smartphone wall adapter power draw'
    },
    {
      id: 'cloudStorageGB',
      label: 'Cloud Storage',
      unit: 'GB Stored',
      icon: Cloud,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10 border-indigo-500/20',
      placeholder: 'e.g. 50',
      hint: 'Data center servers run 24/7'
    },
    {
      id: 'emailsSent',
      label: 'Emails Sent',
      unit: 'Count',
      icon: Mail,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/20',
      placeholder: 'e.g. 25',
      hint: 'Simple email = ~4g CO₂'
    },
    {
      id: 'onlineMeetingsHours',
      label: 'Online Meetings',
      unit: 'Hours',
      icon: Video,
      color: 'text-teal-400',
      bgColor: 'bg-teal-500/10 border-teal-500/20',
      placeholder: 'e.g. 1.5',
      hint: 'Video calling webcam stream'
    },
    {
      id: 'gamingHours',
      label: 'Gaming Hours',
      unit: 'Hours',
      icon: Gamepad2,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10 border-purple-500/20',
      placeholder: 'e.g. 2',
      hint: 'Console/PC high GPU load'
    },
    {
      id: 'aiUsage',
      label: 'AI Usage',
      unit: 'Prompts/Queries',
      icon: Bot,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/20',
      placeholder: 'e.g. 15',
      hint: 'LLM inference & GPU matrix compute'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1d11] via-[#0f2918] to-[#061109] border border-[#153e24] p-6 sm:p-8 shadow-2xl">
        <div className="flex items-center gap-3 mb-2 text-green-400 font-semibold text-xs uppercase tracking-wider">
          <PlusCircle className="w-4 h-4" />
          <span>Activity Log Form</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Log Your Digital Carbon Footprint
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
          Enter your daily digital usage parameters below. Our system will calculate your estimated CO₂ equivalent emissions and sync your activity to Firebase Firestore.
        </p>
      </div>

      {/* Success Notification */}
      {successMsg && (
        <div className="p-6 bg-green-950/80 border border-green-500/50 rounded-2xl text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-fadeIn">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-500/20 rounded-xl text-green-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Activity Successfully Saved!</h3>
              <p className="text-xs text-green-300 mt-0.5">
                Estimated Emission for this entry:{' '}
                <strong className="text-white font-mono text-sm">{successMsg.emission} kg CO₂e</strong>
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2.5 bg-green-600 hover:bg-green-500 text-white text-xs font-semibold rounded-xl shadow-md transition-all shrink-0 flex items-center gap-2"
          >
            <span>Go to Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Error Alert */}
      {errorMsg && (
        <div className="p-4 bg-rose-950/80 border border-rose-500/50 rounded-2xl text-rose-200 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Activity Form */}
      <form onSubmit={handleSubmit} className="glass-card rounded-3xl p-6 sm:p-8 shadow-2xl space-y-8">
        
        {/* Date Selector */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#153e24]">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
              Activity Date
            </label>
            <p className="text-xs text-slate-400">Select the day you are logging for</p>
          </div>
          <input
            type="date"
            required
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            className="bg-[#061109] border border-[#153e24] focus:border-green-500 rounded-xl px-4 py-2 text-white font-mono text-sm focus:outline-none"
          />
        </div>

        {/* Grid of 8 Form Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fields.map((field) => {
            const Icon = field.icon;
            const value = (formData as any)[field.id];

            return (
              <div
                key={field.id}
                className="p-4 bg-[#061109]/80 border border-[#153e24] hover:border-green-500/50 rounded-2xl transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-xl border ${field.bgColor} ${field.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <label className="text-sm font-bold text-white block">{field.label}</label>
                      <span className="text-[11px] text-slate-400">{field.hint}</span>
                    </div>
                  </div>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={value === 0 ? '' : value}
                    onChange={(e) => handleChange(field.id, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full bg-[#0b1d11] border border-[#153e24] focus:border-green-500 rounded-xl py-2.5 pl-4 pr-16 text-white font-mono text-sm focus:outline-none transition-colors"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-500 pointer-events-none">
                    {field.unit}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Calculation Bar */}
        <div className="p-5 bg-gradient-to-r from-green-950/60 to-[#061109] border border-green-500/40 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/20 text-green-400 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                Estimated Total CO₂ Footprint
              </div>
              <div className="text-2xl font-extrabold text-green-400 font-mono">
                {liveCO2} <span className="text-sm font-sans text-slate-300 font-normal">kg CO₂e</span>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto px-8 py-3.5 bg-green-600 hover:bg-green-500 active:scale-[0.99] disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-xl shadow-green-950/80 flex items-center justify-center gap-2 text-sm"
          >
            {submitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving to Firestore...
              </>
            ) : (
              <>
                <Leaf className="w-4 h-4" />
                Submit Activity Log
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
