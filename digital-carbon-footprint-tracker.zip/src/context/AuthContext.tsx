import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut as firebaseSignOut,
  updateProfile as firebaseUpdateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  refreshUserProfile: () => Promise<void>;
  updateUserPhoto: (photoURL: string) => Promise<void>;
  addCO2Saved: (amountKg: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = async (userObj: User) => {
    try {
      const docRef = doc(db, 'users', userObj.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setUserProfile(docSnap.data() as UserProfile);
      } else {
        const displayName = userObj.displayName || userObj.email?.split('@')[0] || 'Eco Leader';
        const defaultProfile: UserProfile = {
          uid: userObj.uid,
          name: displayName,
          email: userObj.email || '',
          photoURL: userObj.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(displayName)}`,
          createdAt: new Date().toISOString(),
          carbonScore: 85,
          totalCO2Saved: 0,
          streakDays: 1,
          lastActiveDate: new Date().toISOString().split('T')[0]
        };
        await setDoc(docRef, defaultProfile);
        setUserProfile(defaultProfile);
      }
    } catch (err) {
      console.error('Error fetching user profile:', err);
      // Fallback in memory profile
      const displayName = userObj.displayName || userObj.email?.split('@')[0] || 'Eco Leader';
      setUserProfile({
        uid: userObj.uid,
        name: displayName,
        email: userObj.email || '',
        photoURL: userObj.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(displayName)}`,
        createdAt: new Date().toISOString(),
        carbonScore: 85,
        totalCO2Saved: 0,
        streakDays: 1,
        lastActiveDate: new Date().toISOString().split('T')[0]
      });
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchUserProfile(user);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const register = async (name: string, email: string, pass: string) => {
    const res = await createUserWithEmailAndPassword(auth, email, pass);
    const user = res.user;

    // Update Firebase Auth profile displayName
    await firebaseUpdateProfile(user, { displayName: name });

    const todayStr = new Date().toISOString().split('T')[0];
    const newProfile: UserProfile = {
      uid: user.uid,
      name,
      email,
      photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name)}`,
      createdAt: new Date().toISOString(),
      carbonScore: 85,
      totalCO2Saved: 0,
      streakDays: 1,
      lastActiveDate: todayStr
    };

    // Store user details in Firebase Firestore
    await setDoc(doc(db, 'users', user.uid), newProfile);
    setUserProfile(newProfile);
  };

  const logout = async () => {
    await firebaseSignOut(auth);
    setUserProfile(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const refreshUserProfile = async () => {
    if (currentUser) {
      await fetchUserProfile(currentUser);
    }
  };

  const updateUserPhoto = async (photoURL: string) => {
    if (!currentUser) return;
    await firebaseUpdateProfile(currentUser, { photoURL });
    const userRef = doc(db, 'users', currentUser.uid);
    await updateDoc(userRef, { photoURL });
    setUserProfile(prev => prev ? { ...prev, photoURL } : null);
  };

  const addCO2Saved = async (amountKg: number) => {
    if (!currentUser || !userProfile) return;
    const newTotal = Math.round((userProfile.totalCO2Saved + amountKg) * 1000) / 1000;
    const newScore = Math.min(99, userProfile.carbonScore + Math.round(amountKg * 2));
    
    const userRef = doc(db, 'users', currentUser.uid);
    await updateDoc(userRef, {
      totalCO2Saved: newTotal,
      carbonScore: newScore
    });

    setUserProfile(prev => prev ? {
      ...prev,
      totalCO2Saved: newTotal,
      carbonScore: newScore
    } : null);
  };

  const value = {
    currentUser,
    userProfile,
    loading,
    login,
    register,
    logout,
    resetPassword,
    refreshUserProfile,
    updateUserPhoto,
    addCO2Saved
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
